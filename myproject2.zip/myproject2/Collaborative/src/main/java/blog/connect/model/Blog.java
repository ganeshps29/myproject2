package blog.connect.model;


import javax.persistence.Entity;
import javax.persistence.Id;




@Entity

public class Blog {
	
	@Id
	private int blogid;    
    private String bcreate_date; 
    private String rating;
    private String btitle;    
    private String bcontent;
    
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getBlogid() {
		return blogid;
	}
	public void setBlogid(int blogid) {
		this.blogid = blogid;
	}
	public String getBcreate_date() {
		return bcreate_date;
	}
	public void setBcreate_date(String bcreate_date) {
		this.bcreate_date = bcreate_date;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
    

}
