package blog.connect.model;

import org.hibernate.validator.constraints.NotEmpty;

public class VBlog {
	private int blogid;
    @NotEmpty(message="Date field is mandatory.")
    private String bcreate_date;
    @NotEmpty(message="Title field is mandatory.")
    private String btitle;
    @NotEmpty(message="Post your content field is mandatory.")
    private String bcontent;
    private String rating;
	public int getBlogid() {
		return blogid;
	}
	public void setBlogid(int blogid) {
		this.blogid = blogid;
	}
	public String getBcreate_date() {
		return bcreate_date;
	}
	public void setBcreate_date(String bcreate_date) {
		this.bcreate_date = bcreate_date;
	}
	public String getBtitle() {
		return btitle;
	}
	public void setBtitle(String btitle) {
		this.btitle = btitle;
	}
	public String getBcontent() {
		return bcontent;
	}
	public void setBcontent(String bcontent) {
		this.bcontent = bcontent;
	}
	public String getrating() {
		return rating;
	}
	public void setrating(String rating) {
		this.rating = rating;
	}
    
    
}
