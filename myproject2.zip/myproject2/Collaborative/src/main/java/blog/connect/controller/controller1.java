package blog.connect.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import blog.connect.Service.BlogServDAO;
import blog.connect.Service.BlogServDAOImpl;
import blog.connect.model.Blog;
import blog.connect.model.VBlog;


@Controller
//@RequestMapping("/wrtBlog")
public class controller1 
{

	@Autowired
	BlogServDAOImpl blogServDAO;	
	
public controller1() {
	///super();
		// TODO Auto-generated constructor stub
	System.out.println("hi");
	}

Blog b=new Blog();
//@RequestMapping(method=RequestMethod.GET)
@RequestMapping("/wrtBlog")
public String showForm(@ModelAttribute(value="blog") Blog blog,ModelMap model){
//    Blog blog = new Blog();
//    model.addAttribute("BLOG", blog);
    return "blog";
}

@RequestMapping(value="addBlog",method=RequestMethod.POST)
public ModelAndView processForm(@ModelAttribute("blog")Blog blog){
	blogServDAO.addBlog(blog);
	
	/*if(result.hasErrors()){ 
    	
    	            return new ModelAndView("blog");
    }else{
    	if(blog.getBlogid()!=0)
    	{
//    	b.setBlogid(blog.getBlogid());
//    	b.setBtitle(blog.getBtitle());
//    	b.setBcontent(blog.getBcontent());
//    	b.setBcreate_date(blog.getBcreate_date());
    	addU(b);
    	return new ModelAndView("chat");
    }
    	else
    	{
    		 return new ModelAndView("blog");
    	}
    }*/
	return new ModelAndView("chat");
}

public void addU(Blog u)
{
	blogServDAO.addBlog(u);
	
}



//****************code for adding Rating******************************************

/*@RequestMapping(value="addRating",method=RequestMethod.POST)
public ModelAndView processForm1(@ModelAttribute("rating")Blog rating){
	blogServDAO.addRating(rating);
	
	return new ModelAndView("chat");
}

public void addR(Blog r)
{
	blogServDAO.addRating(r);
	
}*/
//**********************************************************************************
@RequestMapping("/")
public ModelAndView home(ModelMap model) 
{
    model.addAttribute("greeting", "Hello World from Spring 4 MVC");
    return new ModelAndView("index");
}

@RequestMapping("signin")
public ModelAndView sayHello(ModelMap model) 
{
    model.addAttribute("greeting", "Hello World from Spring 4 MVC");
    return new ModelAndView("SignIn");
}

@RequestMapping("signup")
public ModelAndView sayHello1(ModelMap model)
{
    model.addAttribute("greeting", "Hello World Again, from Spring 4 MVC");
    return new ModelAndView("SignUp");
}

@RequestMapping("chat")
public ModelAndView sayHello2(ModelMap model)
{
    model.addAttribute("greeting", "Hello World Again, from Spring 4 MVC");
    return new ModelAndView("chat");
}

@RequestMapping("blog")
public ModelAndView sayHello3(ModelMap model)
{
    model.addAttribute("greeting", "Hello World Again, from Spring 4 MVC");
    return new ModelAndView("blog");
}

}



