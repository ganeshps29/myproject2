package blog.connect.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import blog.connect.model.Blog;
@Repository("blogDAO")
@Transactional
public class BlogDAOImpl implements BlogDAO{
	
	private List<Blog> listBlog;
	@Autowired
	SessionFactory sessionfactory;
	
	public void addBlog(Blog b) {
		Session sess=sessionfactory.openSession();
		Transaction tx=sess.beginTransaction();
		sess.save(b);
		tx.commit();
		sess.close();	
		
	}

	
	/*public void addRating(Blog r) {
		Session sess=sessionfactory.openSession();
		Transaction tx=sess.beginTransaction();
		sess.save(r);
		tx.commit();
		sess.close();	
		
	}*/
	public void removeBlog(int bid) {
		// TODO Auto-generated method stub
		
	}

	public int getBlogById(int bid) {
		// TODO Auto-generated method stub
		return 0;
	}

	public List<Blog> getBlog() 
	{
		Session sess=sessionfactory.openSession();
		listBlog=sess.createQuery("from Blog").list();
		return listBlog;
	}


//	@Override
//	public int getRatingById(int bid) {
//		// TODO Auto-generated method stub
//		return 0;
//	}

}
