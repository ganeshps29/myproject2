package blog.connect.Service;


import blog.connect.model.Blog;

public interface BlogServDAO {
	public void addBlog(Blog b);
//	public void addRating(Blog r);
	public void removeBlog(int bid);
	public int getBlogById(int bid);

}
