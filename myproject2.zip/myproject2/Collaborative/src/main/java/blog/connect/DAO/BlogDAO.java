package blog.connect.DAO;

import java.util.List;

import blog.connect.model.Blog;

public interface BlogDAO {
	public void addBlog(Blog b);
	public void removeBlog(int bid);
	public int getBlogById(int bid);
//	public int getRatingById(int bid);
	public List<Blog> getBlog();
//	public void addRating(Blog r);


}
