package blog.connect.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import blog.connect.model.Blog;

public class BlogValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object ob, Errors arg1) {
		// TODO Auto-generated method stub
		Blog b=(Blog)ob;
	}

}
