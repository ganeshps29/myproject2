package blog.connect.Service;


import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import blog.connect.DAO.BlogDAO;
import blog.connect.model.Blog;


@Service("blogServDAO")
@Transactional
public class BlogServDAOImpl implements BlogServDAO {
	
	@Autowired
    BlogDAO blogDAO;
	public void addBlog(Blog b) {
		
blogDAO.addBlog(b);
	}

//	 BlogDAO ratingDAO;
//		public void addRating(Blog r) {
//			
//	ratingDAO.addRating(r);
//		}
	public void removeBlog(int bid) {
		// TODO Auto-generated method stub

	}
//
	public int getBlogById(int bid) {
		// TODO Auto-generated method stub
		return 0;
	}


}
